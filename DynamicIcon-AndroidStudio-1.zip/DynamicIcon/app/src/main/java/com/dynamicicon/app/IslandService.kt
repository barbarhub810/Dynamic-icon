package com.dynamicicon.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandService : Service() {
    companion object { const val ACTION_UPDATE = "com.dynamicicon.app.UPDATE_ISLAND"; private const val CHANNEL = "dynamic_icon_status" }
    private lateinit var wm: WindowManager
    private var island: LinearLayout? = null
    private var label: TextView? = null
    private var expanded = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val t = intent?.getStringExtra("title") ?: "Notifikasi baru"
            val d = intent?.getStringExtra("text") ?: ""
            label?.text = "$t  ·  $d"
            expandTemporarily()
        }
    }
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel(); val filter = IntentFilter(ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        startForeground(7, notification())
        showIsland()
        registerReceiver(powerReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }
    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val status = intent?.getIntExtra("status", -1) ?: -1
            if (status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL) {
                label?.text = "⚡  Sedang mengisi daya"; expandTemporarily()
            }
        }
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val c = NotificationChannel(CHANNEL, "Dynamic Icon", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
    private fun notification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Dynamic Icon aktif").setContentText("Dynamic Island sedang ditampilkan").setSmallIcon(android.R.drawable.ic_dialog_info).build()
    }
    private fun showIsland() {
        val pad = (14 * resources.displayMetrics.density).toInt()
        val bg = GradientDrawable().apply { setColor(Color.rgb(8, 9, 14)); cornerRadius = 1000f; setStroke((1 * resources.displayMetrics.density).toInt(), Color.rgb(74, 65, 112)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = bg; setPadding(pad, pad/2, pad, pad/2) }
        val dot = TextView(this).apply { text = "✦"; textSize = 14f; setTextColor(Color.rgb(91, 224, 255)); setPadding(0,0,pad/2,0) }
        label = TextView(this).apply { text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        box.addView(dot); box.addView(label); box.setOnClickListener { expanded = !expanded; label?.text = if (expanded) "Dynamic Icon  •  ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())}" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); resize() }
        island = box
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, (36 * resources.displayMetrics.density).toInt(), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; params.y = (8 * resources.displayMetrics.density).toInt()
        wm.addView(box, params)
    }
    private fun resize() { island?.let { val p = it.layoutParams as WindowManager.LayoutParams; p.width = if (expanded) (280 * resources.displayMetrics.density).toInt() else WindowManager.LayoutParams.WRAP_CONTENT; p.height = (if (expanded) 52 else 36) * resources.displayMetrics.density.toInt(); wm.updateViewLayout(it,p) } }
    private fun expandTemporarily() { expanded = true; resize(); Handler(Looper.getMainLooper()).postDelayed({ if (label != null) { expanded = false; label?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); resize() } }, 4500) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { try { unregisterReceiver(receiver); unregisterReceiver(powerReceiver) } catch (_: Exception) {}; island?.let { wm.removeView(it) }; island = null; label = null; super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
