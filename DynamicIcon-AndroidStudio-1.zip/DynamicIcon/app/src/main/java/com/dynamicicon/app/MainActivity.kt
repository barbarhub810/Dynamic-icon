package com.dynamicicon.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(Color.rgb(246, 246, 250))
        }
        val title = TextView(this).apply { text = "Dynamic Icon"; textSize = 30f; setTextColor(Color.rgb(25,25,35)); gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(8)) }
        val sub = TextView(this).apply { text = "Custom Dynamic Island untuk Android 16"; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(28)) }
        root.addView(title, ViewGroup.LayoutParams(-1, -2)); root.addView(sub, ViewGroup.LayoutParams(-1, -2))
        fun button(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; isAllCaps = false; textSize = 15f; setOnClickListener { action() } }
            val p = LinearLayout.LayoutParams(-1, dp(54)); p.bottomMargin = dp(12); root.addView(b, p)
        }
        button("1. Izinkan tampil di atas aplikasi") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else status("Izin overlay sudah aktif")
        }
        button("2. Aktifkan akses notifikasi") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        button("3. Tampilkan Dynamic Island") {
            if (!Settings.canDrawOverlays(this)) status("Aktifkan izin overlay terlebih dahulu")
            else { startService(Intent(this, IslandService::class.java)); status("Dynamic Island sedang dijalankan") }
        }
        button("Sembunyikan Dynamic Island") { stopService(Intent(this, IslandService::class.java)); status("Dynamic Island dihentikan") }
        val note = TextView(this).apply { text = "Catatan: aktifkan kedua izin agar notifikasi aplikasi dapat muncul di pil. Konten notifikasi diproses di perangkat."; textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(16), 0, 0) }
        root.addView(note)
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
    }
    private fun status(s: String) { android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show() }
}
