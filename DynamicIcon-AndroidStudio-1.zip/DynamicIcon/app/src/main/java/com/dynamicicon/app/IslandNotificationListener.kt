package com.dynamicicon.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()?.take(32) ?: "Notifikasi baru"
        val text = extras.getCharSequence("android.text")?.toString()?.take(52) ?: sbn.packageName
        sendBroadcast(android.content.Intent(IslandService.ACTION_UPDATE).setPackage(packageName).putExtra("title", title).putExtra("text", text))
    }
}
