# Dynamic Icon

Android Studio project for a simple custom floating Dynamic Island prototype.

## Build
1. Open this folder in Android Studio (recent version with Android SDK Platform 36).
2. Let Gradle sync and install missing Android SDK components if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID: `com.dynamicicon.app`  
Target SDK: 36 (Android 16)  
Minimum SDK: 26

## First launch
1. Open Dynamic Icon.
2. Grant "Display over other apps".
3. Open notification access settings and enable Dynamic Icon if you want notification previews.
4. Tap "Tampilkan Dynamic Island".

This is an initial prototype. Notification previews are displayed on screen, so only enable notification access if you are comfortable with that. Some Android 16 / OEM battery-management settings may stop background services; allow background activity if needed.
