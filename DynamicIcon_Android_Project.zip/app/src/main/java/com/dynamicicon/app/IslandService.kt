package com.dynamicicon.app

import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.TextView

class IslandService : Service() {
    private var windowManager: WindowManager? = null
    private var pill: TextView? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = intent.getIntExtra("level", -1)
                val scale = intent.getIntExtra("scale", 100).coerceAtLeast(1)
                val pct = level * 100 / scale
                val status = intent.getIntExtra("status", -1)
                val charging = status == 2 || status == 5
                pill?.text = if (charging) "⚡  $pct%  •  Mengisi daya" else "◆  Dynamic Icon"
            }
        }
    }
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 1000f
            setColor(0xFF050509.toInt())
            setStroke(3, 0xFF9B35FF.toInt())
        }
        pill = TextView(this).apply {
            text = "◆  Dynamic Icon"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = bg
            elevation = 12f
            setPadding(30, 8, 30, 8)
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, 42,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 8 }
        windowManager?.addView(pill, params)
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        try { pill?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        pill = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
