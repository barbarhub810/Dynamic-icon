package com.dynamicicon.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.content.ComponentName
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(0xFF080812.toInt())
        }
        fun label(s: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0, dp(8), 0, dp(8)) }
        layout.addView(label("Dynamic Icon", 30f, 0xFFB45CFF.toInt()))
        layout.addView(label("Dynamic Island untuk Android", 15f, 0xFFB9B9D0.toInt()))
        layout.addView(label("Aktifkan izin yang diperlukan untuk menampilkan pil di atas aplikasi lain.", 14f))
        val overlay = Button(this).apply { text = "1. Izinkan tampil di atas aplikasi" }
        overlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        layout.addView(overlay)
        val notif = Button(this).apply { text = "2. Aktifkan akses notifikasi" }
        notif.setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        layout.addView(notif)
        val start = Button(this).apply { text = "3. Aktifkan Dynamic Island" }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi dulu", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, IslandService::class.java).setAction("SHOW"))
                Toast.makeText(this, "Dynamic Island aktif", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(start)
        val stop = Button(this).apply { text = "Matikan Dynamic Island" }
        stop.setOnClickListener { stopService(Intent(this, IslandService::class.java)) }
        layout.addView(stop)
        layout.addView(label("Fitur dasar: notifikasi, status charging, dan tampilan pil neon ungu-biru. Musik dan pengaturan lanjutan akan dikembangkan setelah pengujian perangkat.", 13f, 0xFFB9B9D0.toInt()))
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
