package com.dynamicicon.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val title = sbn?.notification?.extras?.getCharSequence("android.title")?.toString() ?: return
        val text = sbn.notification.extras?.getCharSequence("android.text")?.toString().orEmpty()
        // Notification access is registered here; displaying app-specific notification content
        // in the overlay will be added after privacy and device-compatibility testing.
    }
}
