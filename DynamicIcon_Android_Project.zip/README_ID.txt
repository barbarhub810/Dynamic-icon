DYNAMIC ICON - PROYEK ANDROID AWAL

Status:
- Ini adalah proyek sumber Android, bukan APK yang sudah dikompilasi.
- Fitur awal: halaman pengaturan, izin overlay, pil overlay dasar, status baterai/charging.
- Akses notifikasi disediakan sebagai service Android, tetapi tampilan isi notifikasi belum dihubungkan ke pil.
- Belum ada kontrol musik, panggilan, timer, mode game, atau editor tema/posisi.

Build:
1. Unggah seluruh isi folder proyek ini ke repository GitHub.
2. Buka tab Actions dan jalankan workflow "Build Dynamic Icon APK".
3. Unduh artifact "DynamicIcon-debug".
4. Ekstrak ZIP artifact untuk memperoleh app-debug.apk.

Catatan kompatibilitas:
- Overlay membutuhkan izin "Tampil di atas aplikasi lain".
- Untuk notifikasi, pengguna harus mengaktifkan akses notifikasi secara manual.
- Android 16 dan Funtouch/OriginOS dapat memiliki pembatasan background/overlay tersendiri.
- Uji pada perangkat sebelum dipakai sehari-hari.
